"""
Flask Web Application
AI Resume Screening & Job Recommendation System

Run with: python app.py
Then open http://127.0.0.1:5000 in your browser.
"""

import os
import sys
from flask import Flask, render_template, request, redirect, url_for, flash
from werkzeug.utils import secure_filename

sys.path.append(os.path.join(os.path.dirname(__file__), "src"))

from extract_text import extract_text
from skill_extractor import extract_skills, load_skills
from matcher import load_job_descriptions, compute_match_scores

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
UPLOAD_FOLDER = os.path.join(BASE_DIR, "uploads")
ALLOWED_EXTENSIONS = {"pdf", "docx"}
JOBS_CSV = os.path.join(BASE_DIR, "data", "job_descriptions.csv")

os.makedirs(UPLOAD_FOLDER, exist_ok=True)

app = Flask(__name__)
app.secret_key = "dev-secret-key-change-in-production"
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER
app.config["MAX_CONTENT_LENGTH"] = 5 * 1024 * 1024  # 5 MB


def allowed_file(filename: str) -> bool:
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


@app.route("/", methods=["GET"])
def index():
    return render_template("index.html")


@app.route("/upload", methods=["POST"])
def upload():
    if "resume" not in request.files:
        flash("No file part in the request.")
        return redirect(url_for("index"))

    file = request.files["resume"]

    if file.filename == "":
        flash("No file selected.")
        return redirect(url_for("index"))

    if not allowed_file(file.filename):
        flash("Unsupported file type. Please upload a PDF or DOCX resume.")
        return redirect(url_for("index"))

    filename = secure_filename(file.filename)
    file_path = os.path.join(app.config["UPLOAD_FOLDER"], filename)
    file.save(file_path)

    try:
        resume_text = extract_text(file_path)
    except Exception as exc:
        flash(f"Could not read the resume: {exc}")
        return redirect(url_for("index"))

    skills_vocab = load_skills()
    found_skills = extract_skills(resume_text, skills_vocab)

    jobs_df = load_job_descriptions(JOBS_CSV)
    ranked = compute_match_scores(resume_text, jobs_df)

    best = ranked.iloc[0]
    results = ranked[["job_role", "match_score"]].to_dict(orient="records")

    return render_template(
        "results.html",
        filename=filename,
        skills=found_skills,
        best_role=best["job_role"],
        best_score=best["match_score"],
        results=results,
    )


if __name__ == "__main__":
    app.run(debug=True)
